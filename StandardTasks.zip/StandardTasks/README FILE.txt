API-Testing : 
- Using the collection file which has been added in the APItest folder to run API in Postman.It has all the subsequent request.

Perf-Test : 
- Use the .jmx file to run the test, which has included the test data .csv file.

AutomationTest-(Docker) : 
- To run the automation test in Docker,run the start docker batch file.
- Open the solution file which has been added in the Mars-Standard Task
- After running the test, Use Shutdown docker batch file



